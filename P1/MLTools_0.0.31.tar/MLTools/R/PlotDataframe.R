#' Plot the data frame vs the output variable
#'
#' @description Function for plotting multiple plots between the output of a data frame and the predictors of this output.
#' \itemize{
#'   \item If the output is continuous
#'   \itemize{
#'      \item It plots a histogram of the output
#'      \item If the predictor is a character (with factor behaviour) or a factor, it makes boxplots of the output divided by the different levels of the factor.
#'      \item If the predictor is numeric
#'      \itemize{
#'         \item If it is continuous, it makes a geom_point plot of the predictor (x-axis) and the output (y-axis). The geom_point plot is approximated by a spline, with a default degree of 3.
#'         \item If it is discrete, and if it has different values less than \code{factor.lev} (default value is 7), the predictor is treated as a factor. If not, it is treated as a continuous predictor.
#'     }
#'   }
#'   \item If the output is discrete
#'   \itemize{
#'      \item It plots a bar plot of the output
#'      \item If the predictor is numeric, it makes a histogram of the predictor divided by the different levels of the output
#'      \item If the predictor is character, it makes a barplot of the predictor divided by the different levels of the output
#'   }
#' }
#' @param fdata dataframe of the data to be plotted, must include the output data
#' @param output.name \code{character}, name of the output variable
#' @param spline.deg \code{integer}, degree of the approximation curve of the geom_point plot. By default is 3
#' @param factor.lev \code{integer}, number of different values that a discrete numeric variable must have to be treated as continuoues.
#' Default is 7
#' @param alpha \code{numeric}, alpha parameter of the ggplots
#' @param bins \code{integer}, bins parameter of the geom_histograms
#' @param facet \code{logical}, if \code{TRUE} and the output is discrete, it divide
#' the plots by the levels of the output. Default is \code{FALSE}
#' @param dens \code{logical}, if \code{TRUE} add a density curve to the histograms. Default is \code{TRUE}
#' @param together \code{logical}, if \code{TRUE} plot all plots together, if \code{FALSE} it goes one by one. Default is \code{TRUE}
#' @examples
#' PlotDataframe(fdata, "Y", 5 , 7)
#' @export PlotDataframe
PlotDataframe <- function(fdata = NULL, output.name = NULL, spline.deg = 3,
                          factor.lev = 7, alpha = 0.4, bins = 30, facet = FALSE,
                          dens = TRUE, together = TRUE) {
  # Check that the data provided is correct
  if (is.null(fdata)||!is.data.frame(fdata)) {
    stop("Please, provide a valid data frame")
    }
  if (is.null(output.name) || !is.character(output.name) || !(output.name %in% variable.names(fdata))) {
    stop("Please, especify the name of the output of the data")

  }

  fdata <- as.data.frame(fdata)

  plotlist <- list() # Empty list where the plots would be stored
  nplots <- length(variable.names(fdata)) # number of plots
  out.num <- which(variable.names(fdata) == output.name) # number of column of the output in the data frame

  # Check if the output is a factor or not
  out.factor <- FALSE
  if (is.factor(fdata[, out.num]) || is.character(fdata[, out.num]) ||
     (length(unique(fdata[, out.num])) < factor.lev)) {
    out.factor <- TRUE
    # Convert the output to a factor if it is not yet a factor
    fdata[, out.num] <- factor(fdata[, out.num])
  }

  # Create plots
  for (i in 1:nplots) {
    local({
      i <- i
      # Check if the variable must be treated as a factor
      var.factor <- is.factor(fdata[, i]) ||
        is.character(fdata[, i]) ||
        (length(unique(fdata[, i])) < factor.lev)

      # Get name of the variable for the labs
      var.name <- names(fdata)[i]

      # If the output is a factor
      if (out.factor) {
        # If the variable to be printed is the output
        if (i == out.num) {
          p <- ggplot2::ggplot(fdata, ggplot2::aes(x = fdata[, out.num],
                                                   y = ..count..,
                                                   fill = factor(fdata[, out.num]))) +
            ggplot2::geom_bar() +
            ggplot2::labs(title = paste("Levels of ", output.name),
                          x = output.name,
                          fill = names(fdata[out.num]))
          plotlist[[i]] <<- p

        } else if (var.factor) {
          # If the variable is a factor
          # Convert it to a factor if it is not yet a factor
          fdata[, i] <- factor(fdata[, i])
          p <- ggplot2::ggplot(fdata, ggplot2::aes(x = fdata[, i], y = ..count..)) +
            ggplot2::geom_bar(ggplot2::aes(fill = fdata[, out.num], color = fdata[, out.num]),
                              alpha = alpha, position = "dodge") +
            ggplot2::labs(title = paste(var.name, " vs ", output.name),
                          x = var.name, colour = output.name, fill = output.name)
          plotlist[[i]] <<- p
        } else {
          # The variable is not a factor
          p <- ggplot2::ggplot(fdata, ggplot2::aes_string(var.name,
                                                          color = output.name,
                                                          fill = output.name)) +
            ggplot2::geom_histogram(ggplot2::aes(y = ..count..), alpha = alpha, bins = bins) +
            ggplot2::labs(title = paste(var.name, " vs ", output.name),
                          x = var.name)
          if (facet) {
            p <- p +
              ggplot2::facet_grid(fdata[, out.num] ~ .)
          }
          if (dens) {
            p <- p +
              ggplot2::geom_density(alpha = alpha, ggplot2::aes(y = ..count..))

          }
          plotlist[[i]] <<- p
        }
      } else {
        # If the output is not a factor
        if (i == out.num) {
          # If the variable to be printed is the output
          p <- ggplot2::ggplot(fdata, ggplot2::aes(x = fdata[, out.num],
                                                   y = ..count..,
                                                   fill = fdata[, out.num],
                                                   color = fdata[, out.num])) +
            ggplot2::geom_histogram(alpha = alpha, bins = bins) +
            ggplot2::labs(title = paste("Histogram of ", output.name),
                          x = output.name)
          if (facet) {
            p <- p +
              ggplot2::facet_grid(fdata[, out.num] ~ .)
          }
          if (dens) {
            p <- p +
              ggplot2::geom_density(alpha = alpha)
          }
          plotlist[[i]] <<- p
        } else if (var.factor) {
          fdata[, i] <- factor(fdata[, i])
          # Make a boxplot of the output based on the predictor
          p <- ggplot2::ggplot(fdata, ggplot2::aes_string(x = colnames(fdata)[i],
                                                          y = colnames(fdata)[out.num],
                                                          color = colnames(fdata)[i],
                                                          fill = colnames(fdata)[i])) +
            ggplot2::geom_boxplot(notch = TRUE, alpha = alpha) +
            ggplot2::labs(title = paste(output.name, " vs ",
                                        var.name),
                          x = var.name)
          if (facet) {
            p <- p +
              ggplot2::facet_grid(fdata[, i] ~ .)
          }
          plotlist[[i]] <<- p
        } else {
          # Output and predictor are continuous
          p <- ggplot2::ggplot(fdata, ggplot2::aes_string(x = colnames(fdata)[i],
                                                          y = colnames(fdata)[out.num])) +
            ggplot2::geom_point() +
            ggplot2::geom_smooth(method = "lm", formula = y ~ splines::bs(x, spline.deg),
                                 se = FALSE, color = 'blue') +
            ggplot2::labs(title = paste(output.name, " vs ", var.name),
                          x = var.name, y = output.name)
          plotlist[[i]] <<- p
        }
      }
    })
  }
  # Plot the list of plots created before
  if (!together) {
    # One by one
    for (i in 1:length(plotlist)){
      print(plotlist[[i]])
      response <- readline("Continue plotting? [yes/no]: ")
      if (response %in% c("n","N","no","NO","No")) {
        break
      }
    }
  } else {
    # All together
    gridExtra::grid.arrange(grobs = plotlist,
                            nrow = floor(sqrt(length(plotlist))),
                            ncols = ceiling(sqrt(length(plotlist))))
  }
}
