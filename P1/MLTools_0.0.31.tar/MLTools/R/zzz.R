.onLoad <- function(libname, pkgname) {
  packageStartupMessage("   __    __   _            _________\n  |  \\  /  | | |          |___   ___| _____   _____   _      _____\n  |   \\/   | | |     ____     | |    |  _  | |  _  | | |    |  ___|\n  | |\\  /| | | |    |____|    | |    | | | | | | | | | |    |___  |\n  | | \\/ | | | |____          | |    | |_| | | |_| | | |__   ___| |\n  |_|    |_| |______|         |_|    |_____| |_____| |____| |_____|\n\n           Learning is fun, Machine Learning is funnier\n            -----------------------------------------\n           With great power comes great responsibility\n            -----------------------------------------")
  packageStartupMessage("Created by:\n        Jos\xe9 Portela Gonz\xe1lez   <Jose.Portela@iit.comillas.edu>
        Guillermo Mestre Marcos <Guillermo.Mestre@comillas.edu>
        Jaime Pizarroso Gonzalo <jpizarroso@comillas.edu>
        Antonio Mu\xf1oz San Roque <antonio.munoz@iit.comillas.edu>")
  packageStartupMessage("\n            Escuela T\xe9cnica Superior de Ingenier\xeda ICAI")
  }

