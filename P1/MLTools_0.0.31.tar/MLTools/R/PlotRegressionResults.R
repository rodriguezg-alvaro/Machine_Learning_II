#' Analyze results of Regression models
#'
#' @description Function to plot the regression predictions against the real values. A perfect prediction
#' would be a diagonal line (drawn in the plots as a red dashdotted line). The precision measures of the
#' predictions are added in each of the plots and are shown in the console.
#' @param fdata Dataframe with the output variables and the predictions variables.
#' If \code{pred.names} is \code{NULL}, the predictions variables are considered to be
#' the variables after the output variable in this dataframe.
#' @param output.name \code{character} name of the output variable
#' @param pred.names \code{character} vector with the name of the predictions variables
#' @param together \code{logical} if TRUE, all the plots are shown together. This is recommended to compare
#' two models, more prediction would make a confusing plot. The precision measures are not added in the plot.
#' @examples
#' PlotRegressionResults(fdataTR_eval[,c(10:12)],"PRICE_SP", c("lm_pred"))
#' plotRegressionResults(fdataTV_eval[,c(10,14:17)],"PRICE_SP")
#' @export PlotRegressionResults
PlotRegressionResults <- function(fdata = NULL,
                                  output.name = NULL,
                                  pred.names = NULL,
                                  together = FALSE) {
  # Check that the data provided is correct
  if (is.null(fdata)) {
    stop("Please, provide a valid data frame")

  } else if (is.null(output.name) || !is.character(output.name)) {
    stop("Please, especify the name of the output of the data")

  } else if (!(output.name %in% variable.names(fdata))) {
    stop("The output data can not be found in the data provided")
  }

  # Check for tibbles or matrix
  if (ncol(fdata) > 1) {
    fdata <- as.data.frame(fdata)
  }

  plotlist <- list() # Empty list where the plots would be stored
  df.plot <- data.frame("output" = fdata[, output.name])
  # Check the variables with the model predictions
  if (is.null(pred.names)) {
    # If no predictions variables are specified, the predictions are
    # the variables after the output data
    out.num <-
      which(variable.names(fdata) == output.name) #number of column of the output in the data frame
    df.plot[, 2:(1 + ncol(fdata) - out.num)] <-
      fdata[, (out.num + 1):ncol(fdata)]
  } else if (all(pred.names %in% variable.names(fdata))) {
    # Check if the predictions are in the dataframe
    df.plot[, 2:(1 + length(pred.names))] <- fdata[, pred.names]
    names(df.plot) <- c("output", pred.names)
  } else {
    stop("No prediction data has been detected")
  }
  #Create colors
  color <- topo.colors(ncol(df.plot) - 1)
  if (together) {
    # Plot the predictions together
    # Create the diagonal line
    df.line <- data.frame(x.values = c(min(df.plot[, 1]) - 2,
                                       max(df.plot[, 1]) + 2),
                          y.values = c(min(df.plot[, 1]) - 2,
                                       max(df.plot[, 1]) + 2))
    ploti <- ggplot2::ggplot() +
      ggplot2::geom_line(
        data = df.line,
        ggplot2::aes(x = x.values, y = y.values),
        linetype = "dotdash",
        color = "red",
        size = 1.2
      ) +
      ggplot2::labs(
        title = "predictions",
        x = variable.names(df.plot)[1],
        y = "predictions"
      )
    for(i in 2:ncol(df.plot)){
      local({
        i <- i
        ploti <<- ploti +
          ggplot2::geom_point(data = df.plot,
                              ggplot2::aes(x = df.plot[, 1], y = df.plot[, i]),
                              color = color[i - 1])
        # Calculate R-squared between predictions and output
        R2 <- cor(df.plot[, 1], df.plot[, i]) ^ 2
        rmse <- RMSE(df.plot[, 1], df.plot[, i])
        mae <- MAE(df.plot[, 1], df.plot[, i])
        cat("-----------------------\n",
            variable.names(df.plot)[i],
            "\nR2 \t",R2,
            "\nRMSE \t", rmse,
            "\nMAE \t", mae, "\n")
      })
      print(ploti)
    }
  } else {
    # Plot the predictions in separated plots
    for (i in 2:ncol(df.plot)) {
      local({
        i <- i
        # Create values for diagonal line
        df.line <- data.frame(x.values = c(min(df.plot[, 1]) - 2,
                                           max(df.plot[, i]) + 2),
                              y.values = c(min(df.plot[, 1]) - 2,
                                           max(df.plot[, i]) + 2))
        # Calculate R-squared between predictions and output
        R2 <- cor(df.plot[, 1], df.plot[, i]) ^ 2
        rmse <- RMSE(df.plot[, 1], df.plot[, i])
        mae <- MAE(df.plot[, 1], df.plot[, i])
        precision <- data.frame("R2" = R2,
                                "RMSE" = rmse,
                                "MAE" = mae)
        cat("-----------------------\n",
            variable.names(df.plot)[i],
            "\nR2 \t",R2,
            "\nRMSE \t", rmse,
            "\nMAE \t", mae, "\n")
        ploti <- ggplot2::ggplot() +
          ggplot2::geom_point(data = df.plot,
                              ggplot2::aes(x = df.plot[, 1], y = df.plot[, i]),
                              color = color[i - 1]) +
          ggplot2::geom_line(
            data = df.line,
            ggplot2::aes(x = x.values, y = y.values),
            linetype = "dotdash",
            color = "red",
            size = 1.2
          ) +
          ggplot2::labs(
            title = paste("predictions of", variable.names(df.plot[i])),
            x = variable.names(df.plot)[1],
            y = variable.names(df.plot)[i]
          ) +
          ggplot2::geom_text(
            data = precision,
            x = 0.5 * (max(max(df.plot[, 1]), max(df.plot[, i])) + min(min(df.plot[, 1]), min(df.plot[, i]))),
            y = max(max(df.plot[, 1]), max(df.plot[, i])),
            ggplot2::aes(
              label = paste(
                "R-squared =",
                as.character(round(R2, digits = 3)),
                "\nRMSE =",
                as.character(round(RMSE, digits = 3)),
                "\nMAE =",
                as.character(round(MAE, digits = 3))
              )
            )
          )
        plotlist[[i - 1]] <<- ploti
      })
    }
    # Plot the list of plots created before
    gridExtra::grid.arrange(grobs = plotlist,
                            nrow = floor(sqrt(length(plotlist))),
                            ncols = ceiling(sqrt(length(plotlist))))

  }
}
