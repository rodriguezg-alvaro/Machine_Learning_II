#' Analyze results of classification models
#'
#' @description Custom function for plotting the results of a classification model with two input variables and
#' a classification output variable.It let's you choose which class to plot the probabilities.
#' @param X Data frame with two input variables
#' @param Y Vector with real output variable, should be a factor
#' @param model Fitted model using caret
#' @param var1 \code{character}, name of the x-axis variable
#' @param var2 \code{character}, name of the y-axis variable
#' @param selClass \code{character}, class to be analyzed (probabilities). If \code{NULL}, an interactive list let you choose the class analyzed.
#' @param np.grid \code{integer}, number of discretization points in each dimension
#' @param real \code{logical}, if \code{TRUE} the classes with estimated lines are the real ones, else, are the predicted ones. By default is \code{TRUE}.
#' @section Output:
#' \itemize{
#'   \item Plot 1: colorful plot with the classification of the classes in a 2D map
#'   \item Plot 2: b/w plot with probability of the chosen class in a 2D map
#'   \item Plot 3: plot with the predictions of the data provided
#' }
#' It does not return any object.
#' @examples
#' plot2Dclass(fdata, fdata[, "Y"], var1 = "X1", var2 = "X2", selClass = "YES", lm.fit, 300)
#' @export Plot2DClass
Plot2DClass <-
  function(X,
           Y,
           model,
           var1 = NULL,
           var2 = NULL,
           selClass = NULL,
           np.grid = 200,
           real = TRUE) {

    #Check that X has two variables
    if ( ncol(X) < 2 ){
      stop("There have to be at least 2 input variables")
    }
    # Check for tibbles
    X <- as.data.frame(X)
    # Check input variable names
    if (is.null(var1) | is.null(var2)) {
      stop("Please, introduce the variable names for each axis (var1 and var2)")
    }

    # Change input variable colnames to X1 and X2 and output to Y
    c.names <- colnames(X)
    # Check input variable names
    if (sum(c(var1, var2) %in% c.names) < 2) {
      stop(paste("Variable ", var1, " or ", var2, " do not exist in the data"))
    }
    fdata <- X[,c(var1,var2)]
    fdata$Y <- Y
    colnames(fdata) <- c("X1", "X2", "Y")

    # If there are only two input variables, plot partition of input space
    if (ncol(X) == 2) {
      # Grid for evaluating the model
      np.X1 <-
        seq(
          from = min(fdata$X1),
          to = max(fdata$X1),
          length.out = np.grid
        )
      np.X2 <-
        seq(
          from = min(fdata$X2),
          to = max(fdata$X2),
          length.out = np.grid
        )
      grid.X1.X2 <- expand.grid(X1 = np.X1, X2 = np.X2)
      colnames(grid.X1.X2) <- c.names

      # Predict each point of the grid
      grid.X1.X2$pred <-
        predict(model, type = "raw", newdata = grid.X1.X2) # predict class

      # Obtain probabilites of the model in the grid and add to the grid data frame
      for (i in seq_len(length(levels(fdata$Y)))) {
        grid.X1.X2[, ncol(grid.X1.X2) + 1] <-
          predict(model, type = "prob", newdata = grid.X1.X2)[, i]
        names(grid.X1.X2)[ncol(grid.X1.X2)] <-
          paste("prob", levels(fdata$Y)[i], sep = "_")
      }

      names(grid.X1.X2)[1:2]<-c("X1", "X2")
    }

    # Predict input data
    pred <-
      predict(model, type = "raw" , newdata = X) # predict class
    fdata <- cbind(fdata, pred)

    # List to plot all the plots together
    plotlist <- list()
    # Select variable to plot
    if (is.null(selClass)) {
      response <- select.list(
        levels(fdata$Y),
        multiple = FALSE,
        graphics = TRUE,
        title = "Choose variable to plot"
      )
    } else{
      response <- selClass
    }

    if (response != "") {
      # If there are only two input variables, plot partition of input space
      if (ncol(X) == 2) {
        prob <- paste("prob", response, sep = "_")
        # Add variable to grid which is the variable to plot
        grid.X1.X2$prob <-
          grid.X1.X2[, grep(prob, names(grid.X1.X2))]

        # Classification of input space
        plotlist[[1]] <- ggplot2::ggplot() +
          ggplot2::geom_point(data = grid.X1.X2,
                              mapping = ggplot2::aes(
                                x = X1,
                                y = X2,
                                colour = pred
                              )) +
          ggplot2::labs(title = "Classification of input space", x = var1, y = var2) +
          ggplot2::theme(legend.position = "right")

        # Probabilities estimated for input space
        plotlist[[2]] <- ggplot2::ggplot() +
          ggplot2::geom_point(data = grid.X1.X2,
                              mapping = ggplot2::aes(
                                x = X1,
                                y = X2,
                                colour = prob
                              )) +
          ggplot2::labs(
            title = paste(
              "Probabilities estimated for input space, class:",
              response
            ),
            x = var1,
            y = var2
          ) +
          ggplot2::theme(legend.position = "right")


        # Classification resutls
        plotlist[[3]] <- ggplot2::ggplot() +
          ggplot2::stat_contour(
            data = grid.X1.X2,
            mapping = ggplot2::aes(x = X1, y = X2, z = prob),
            colour = "navyblue",
            breaks = 0.5
          ) +
          ggplot2::geom_point(data = cbind(fdata,
                                           Y_Yest <-
                                             interaction(fdata$Y, pred, sep = "_")),
                              ggplot2::aes(x = X1, y = X2, color = Y_Yest))
        plotlist[[3]] <- plotlist[[3]] +
          ggplot2::labs(
            title = paste("Classification results, class:", response),
            x = var1,
            y = var2
          ) +
          ggplot2::theme(legend.position = "right")


        # Plot of probabilities
        plotlist[[4]] <- ggplot2::ggplot() +
          ggplot2::stat_contour(
            data = grid.X1.X2,
            mapping = ggplot2::aes(
              x = X1,
              y = X2,
              z = prob,
              colour = ..level..
            ),
            binwidth = 0.1
          ) +
          ggplot2::geom_point(
            data = fdata,
            ggplot2::aes(
              x = X1,
              y = X2,
              fill = levels(Y)[ifelse(rep_len(real, length.out = nrow(fdata)),Y,pred)]
            ),
            shape = 21,
            color = "NA"
          ) +
          ggplot2::labs(title = paste(
            paste0(
              ifelse(real, "Real ", "Predicted "),
              "classes and estimated probability contour lines for class:"
            ),
            response
          ),
          x = var1,
          y = var2,
          fill = ifelse(real, "Y", "pred"))
        # plotlist[[4]] <- direct.label(plotlist[[4]], method="bottom.pieces") # label of contour lines


        # Plot the list of plots created before
        gridExtra::grid.arrange(
          grobs = plotlist,
          nrow = floor(sqrt(length(plotlist))),
          ncols = ceiling(sqrt(length(plotlist)))
        )

      } else {
        prob <- paste("prob", response, sep = "_")

        # Classification resutls
        plotlist[[1]] <- ggplot2::ggplot() +
          ggplot2::geom_point(data = cbind(fdata,
                                           Y_Yest <-
                                             interaction(fdata$Y, pred, sep = "_")),
                              ggplot2::aes(x = X1, y = X2, color = Y_Yest))
        plotlist[[1]] <- plotlist[[1]] +
          ggplot2::labs(
            title = paste("Classification results, class:", response),
            x = var1,
            y = var2
          ) +
          ggplot2::theme(legend.position = "right")

        # Estimated classes
        plotlist[[2]] <- ggplot2::ggplot() +
          ggplot2::geom_point(data = fdata, ggplot2::aes(x = X1, y = X2, color = pred)) +
          ggplot2::labs(
            title = paste("Estimated classes:", response),
            x = var1,
            y = var2
          )


        # Plot the list of plots created before
        gridExtra::grid.arrange(grobs = plotlist,
                                nrow = 1,
                                ncols = 2)
      }
    }
  }
