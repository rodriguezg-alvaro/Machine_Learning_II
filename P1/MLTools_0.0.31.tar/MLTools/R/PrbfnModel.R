#' Train a probabilistic rbf network model
#'
#' @description Function to train a probabilistic rbf network model
#' @param x data to train the model
#' @param nh \code{integer} number of clusters to be made
#' @param nc \code{integer} training parameter
#' @return prbfn model
#' @examples
#' # Prbfn
#' tunegrid <- seq(2, 31, by = 1)
#' ssq_prbfn <- matrix(ncol = length(tunegrid), nrow = 1)
#' i <- 1
#' for(k in tunegrid){
#'   Sys.sleep(0.2)
#'   prbfn <- train.prbfn(fdata, k, 40)
#'   # Total sum of squares
#'   ssq_prbfn[i] <- Reconstruction.Error(prbfn$centers, prbfn$cluster, fdata)
#'   i <- i + 1
#' }
#' @export train.prbfn
train.prbfn <- function(x, nh, nc = 100){

  ##Platform
  platform <- Sys.info()[['sysname']]

  # Check for tibbles
  x <- as.data.frame(x)

  ##Path settings
  wdpath <- getwd()
  libpath <- .libPaths()[1]
  exepath <- paste(libpath,"/MLTools/exec",sep = "")

  ##Data preparation
  #omit NAs
  x <- na.omit(x)
  #Check for equal columns

  ##Model training
  #Set working directory
  setwd(exepath)
  #write data to text file
  write.table(x = x,file = "Prbfn.tr",row.names = FALSE,col.names = FALSE)
  #Create call
  switch(platform,
         "Windows"={
           prog=sprintf("prbfnii_w_fdp.exe %s %d %d 0 %d 0 %s.tr %s.tr %s.tr",
                        "Prbfn",ncol(x),nh,nc,"Prbfn","Prbfn","Prbfn")
           shell(prog)
         },
         "Darwin"={
           prog=sprintf("./prbfnii_w_fdp %s %d %d 0 %d 0 %s.tr %s.tr %s.tr",
                        "Prbfn",ncol(x),nh,nc,"Prbfn","Prbfn","Prbfn")
           #system(paste("cd ",exepath," && " ,prog))
           system(prog)
         })

  #Read output file
  fout <- read.table(file = "Prbfn.out",header = FALSE)
  fout <- fout[,1:3]
  colnames(fout) <- c("log.lik","norm.lik","kern.id")
  fout$kern.id <- fout$kern.id + 1
  #Read nvr
  nvr <- read.table(file = "Prbfn.nvr",header = FALSE)
  #Read prc
  prc <- read.table(file = "Prbfn.prc",header = FALSE)
  #Read rep
  rep <- read.table(file = "Prbfn.rep",header = FALSE)
  colnames(rep) <- colnames(x)
  row.names(rep) <- 1:nh
  #Read sig
  sig <- read.table(file = "Prbfn.sig",header = FALSE)
  #Read wa
  wa <- read.table(file = "Prbfn.wa",header = FALSE)

  #Return to original working directory
  setwd(wdpath)

  #create model
  model <- list(x = x,
                out = fout,
                nvr = nvr,
                prc = prc,
                centers = rep,
                cluster = fout$kern.id,
                #tot.withins = tot.withins,
                sig = sig,
                wa = wa,
                nh = nh,
                nc = nc)

  return(model)
}

#' Predict classes with a probabilistic rbf network model
#'
#' @description Function to predict classes of a given data using a probabilistic rbf network model
#' @param model prbfn model trained by the function above
#' @param x.new new data to be classified
#' @return data frame with the classification result of the data
#' @examples
#' clasdata <- predict.prbfn(prbfn, fdata)
#' @export predict.prbfn
predict.prbfn <- function(model, x.new){

  ##Path settings
  wdpath <- getwd()
  libpath <- .libPaths()[1]
  exepath <- paste(libpath,"/MLTools/exec",sep = "")

  # Check for tibbles
  x.new <- as.data.frame(x.new)

  #Set working directory
  setwd(exepath)

  ##Platform
  platform <- Sys.info()[['sysname']]

  #Crea el fichero con los representantes a partir de los datos almacenados en el modelo
  write.table(model$centers, "Prbfn.rep", row.names = FALSE,col.names = FALSE)
  #Crea el fichero con los desviaciones a partir de los datos almacenados en el modelo
  write.table(model$sig, "Prbfn.sig", row.names = FALSE,col.names = FALSE)
  #Crea el fichero con los desviaciones a partir de los datos almacenados en el modelo
  write.table(model$nvr, "Prbfn.nvr", row.names = FALSE,col.names = FALSE)
  #Crea el fichero con los desviaciones a partir de los datos almacenados en el modelo
  write.table(model$wa, "Prbfn.wa", row.names = FALSE,col.names = FALSE)
  #Crea el fichero con los porcentajes a partir de los datos almacenados en el modelo
  write.table(model$prc, "Prbfn.prc", row.names = FALSE,col.names = FALSE)

  #Crea el fichero de validacion
  write.table(x.new, "Prbfn.tv", row.names = FALSE,col.names = FALSE)

  switch(platform,
         "Windows"={
           prog=sprintf("prbfnii_w_fdp %s %d %d 0 %d 0 - - %s.tv",
                        "Prbfn",ncol(x.new),model$nh,model$nc,"Prbfn")
           shell(prog)
         },
         "Darwin"={
           prog=sprintf("./prbfnii_w_fdp %s %d %d 0 %d 0 - - %s.tv",
                        "Prbfn",ncol(x.new),model$nh,model$nc,"Prbfn")
           #system(paste("cd ",exepath," && " ,prog))
           system(prog)
         })


  #Incluimos el representante asociado a cada vector de datos
  #Read output file
  fout <- read.table(file = "Prbfn.out",header = FALSE)
  fout <- fout[,1:3]
  colnames(fout) <- c("log.lik","norm.lik","kern.id")
  fout$kern.id <- fout$kern.id + 1

  #Return to original working directory
  setwd(wdpath)


  return(fout)
}
