#' Identification plot of a transfer function forecasting model
#'
#' @description Receives a model fitted with the arima function from TSA package
#' with exogenous vairables modeled with transfer functions. The estimated importance
#' parameters of the model are printed
#' @param x \code{ts vector/dataframe/tibble} training data used for the model
#' @param arima.fit Transfer function forecasting model
#' @param alpha \code{numeric} alpha parameter to compare the p-values with a certain significance level
#' @export TF.Identification.plot
TF.Identification.plot <- function(x = NULL, arima.fit, alpha = 0.05) {
  # Receives a model fitted with the arima function from TSA package
  # with exogenous vairables modeled with transfer functions.

  coefdata <- lmtest::coeftest(arima.fit)
  coefnames <- attr(coefdata, which = "dimnames")[[1]]

  # Plot values of numerator coefficients
  if (is.null(ncol(x))) {
    # One regressor variable
    indexcoef <- grep("-MA", coefnames)
    indexnum <- substring(coefnames[indexcoef],6,nchar(coefnames[indexcoef]))
    # Check that all index has the same number of characters
    if (!all(nchar(indexnum)==max(nchar(indexnum)))) {
      indexnotmax <- which(nchar(indexnum)!=max(nchar(indexnum)))
      cerostomax <- max(nchar(indexnum)) - nchar(indexnum[indexnotmax])
      zeros <- c()
      for (i in 1:length(cerostomax)) {
        zeros <- c(zeros,paste(rep("0",cerostomax[i]),collapse = ""))
      }
      coefnames[indexcoef[indexnotmax]] <- paste0("T1-MA",
                                                  zeros,
                                                  substr(coefnames[indexcoef[indexnotmax]],6,
                                                         nchar(coefnames[indexcoef[indexnotmax]])))
      attr(coefdata, which = "dimnames")[[1]] <- coefnames
    }
    plotdata <-
      data.frame(values = coefdata[indexcoef, 1], names = coefnames[indexcoef], pvalor = coefdata[indexcoef,4])
    P1 <- ggplot2::ggplot(plotdata) +
      ggplot2::geom_col(ggplot2::aes(x = names , y = values)) +
      ggplot2::labs(title = "Estimates of TF coefficients", x = "Coefficients") +
      ggplot2::ylab('Coefficient value') +
      ggplot2::geom_line(ggplot2::aes(x = 1:nrow(plotdata), y = pvalor*max(values), colour = 'p-value'), size = 1) +
      ggplot2::geom_point(ggplot2::aes(x = 1:nrow(plotdata), y = pvalor*max(values), colour = 'p-value'), size = 3) +
      ggplot2::scale_y_continuous(sec.axis = ggplot2::sec_axis(~./max(plotdata$values), 
                                                               name = "P-value"))+ 
      ggplot2::theme(legend.position = c(0.85, 0.3), legend.title = ggplot2::element_blank()) +
      ggplot2::geom_hline(ggplot2::aes(yintercept = alpha * max(values), colour = paste0('alpha = ', as.character(alpha))), 
                          linetype = 'dashed', size = 1) +
      ggplot2::scale_colour_manual(values = c("red", "blue")) + 
      ggplot2::labs(colour = '')
      
    print(P1)
    # Display significance
    print(coefdata[indexcoef,])

  } else {
    # Number of explanatory variables
    nx <- ncol(x)
    #Check if the dataframe provided is a tibble, give it back as a data.frame
    if (ncol(x) > 1) {
      x <- as.data.frame(x)
    }
    # Several regressor variables
    # Variable names
    nomx <- colnames(x)
    # List to plot all the plots together
    plotlist <- list()
    # Loop
    for (ii in 1:nx) {
      # MA regression terms
      indexcoef <- grep(paste(nomx[ii], "-MA", sep = ""), coefnames)
      indexnum <- substring(coefnames[indexcoef],6,nchar(coefnames[indexcoef]))
      # Check that all index has the same number of characters
      if (!all(nchar(indexnum)==max(nchar(indexnum)))) {
        indexnotmax <- which(nchar(indexnum)!=max(nchar(indexnum)))
        cerostomax <- max(nchar(indexnum)) - nchar(indexnum[indexnotmax])
        zeros <- c()
        for (i in 1:length(cerostomax)) {
          zeros <- c(zeros,paste(rep("0",cerostomax[i]),collapse = ""))
        }
        coefnames[indexcoef[indexnotmax]] <- paste0(nomx[ii],"-MA",
                                                    zeros,
                                                    substr(coefnames[indexcoef[indexnotmax]],6,
                                                           nchar(coefnames[indexcoef[indexnotmax]])))
        attr(coefdata, which = "dimnames")[[1]] <- coefnames
      }
      plotdata <-
        data.frame(values = coefdata[indexcoef, 1], names = coefnames[indexcoef], pvalor = coefdata[indexcoef,4])
      ploti <- ggplot2::ggplot(plotdata) +
        ggplot2::geom_col(ggplot2::aes(x = names , y = values)) +
        ggplot2::labs(title = "Estimates of TF coefficients", x = "Coefficients") +
        ggplot2::ylab('Coefficient value') +
        ggplot2::geom_line(ggplot2::aes(x = 1:nrow(plotdata), y = pvalor*max(values), colour = 'p-value'), size = 1) +
        ggplot2::geom_point(ggplot2::aes(x = 1:nrow(plotdata), y = pvalor*max(values), colour = 'p-value'), size = 3) +
        ggplot2::scale_y_continuous(sec.axis = ggplot2::sec_axis(~./max(plotdata$values), 
                                                                 name = "P-value"))+ 
        ggplot2::theme(legend.position = c(0.85, 0.3), legend.title = ggplot2::element_blank()) +
        ggplot2::geom_hline(ggplot2::aes(yintercept = alpha * max(values), colour = paste0('alpha = ', as.character(alpha))), 
                            linetype = 'dashed', size = 1) +
        ggplot2::scale_colour_manual(values = c("red", "blue")) + 
        ggplot2::labs(colour = '')+
        ggplot2::labs(title = paste(nomx[ii], ": Estimates of TF coefficients"),
                      x = "Coefficients")
      plotlist[[ii]] <- ploti
      # Display significance
      print(nomx[ii])
      print(coefdata[indexcoef,])
    }
    # Plot the list of plots created before
    gridExtra::grid.arrange(grobs = plotlist,
                            nrow = floor(sqrt(length(plotlist))),
                            ncols = ceiling(sqrt(length(plotlist))))
  }
}

#' Plot regression error of a transfer function forecasting model
#'
#' @description Plot the error, ACF and PACF plots of the transfer function
#' forecasting model to see if the coefficients of the model must be changed.
#' @param y \code{numeric vector} output of the data
#' @param x \code{numeric vector} input of the data
#' @param arima.fit \code{model} transfer function model
#' @param lag.max \code{integer} lag to plot the ACF and PACF plots
#' @export TF.RegressionError.plot
TF.RegressionError.plot <- function(y, x, arima.fit, lag.max = 25) {
  # y = real data
  # x = explanatory variables,
  # arima.fit = model

  #Calculate regression error
  regerr <- MLTools::TF.RegressionError(y, x, arima.fit)

  # Check differences and adapt title
  # Extract fitted info
  orders <- arima.fit$arma
  # Create text
  Btext <- ""
  if (orders[6] > 0) {
    Btext <- paste(Btext, "(1-B)", sep = "")
  }
  if (orders[7] > 0) {
    Btext <- paste(Btext, "(1-B)^", orders[5], sep = "")
  }

  # Plot ACF and PACF of regression error
  forecast::ggtsdisplay(
    regerr,
    lag.max = lag.max,
    main = paste0(
      "TF regression error: v[t] = ",
      Btext,
      "y[t] - filter(",
      Btext,
      "x[t])"
    )
  )
}

#' Calculate regression error of a transfer function forecasting model
#'
#' @description Calculate the error of the transfer function forecasting model
#' in order to plot it later and see if the coefficients must be changed.
#' @param y \code{numeric vector} output of the data
#' @param x \code{numeric vector} input of the data
#' @param arima.fit \code{model} transfer function model
#' @return \code{numeric vector} regression error
#' @export TF.RegressionError
TF.RegressionError <- function(y, x, arima.fit) {
  # y = real data
  # x = explanatory variables,
  # arima.fit = model


  ######Effect of explanatory variable
  coefval <- coef(arima.fit)
  coefnames <- attr(coefval, which = "names")
  xfilt <- MLTools::TF.filter(x, coefval, coefnames)

  #intercept
  indexcoef <- grep("intercept", coefnames)
  if (length(indexcoef) == 0) {
    inter <- 0
  } else {
    inter <- coefval[indexcoef]
  }

  #extract fitted info
  orders <- arima.fit$arma

  #Regression error
  y.diff <- y
  x.diff <- xfilt
  if (orders[6] > 0) {
    y.diff <- diff(y.diff, differences = orders[6])
    x.diff <- diff(x.diff, differences = orders[6])
  }
  if (orders[7] > 0) {
    y.diff <- diff(y.diff, lag = orders[5], differences = orders[7])
    x.diff <- diff(x.diff, lag = orders[5], differences = orders[7])
  }

  regerr <- y.diff - x.diff - inter

  return(regerr)
}


#' Predict new values using a transfer function forecasting mode
#'
#' @description Predict new values using a transfer function forecasting
#' model and new input data.
#' @param y.old \code{numeric vector} training output of the data
#' @param x.old \code{numeric vector} training input of the data
#' @param x.new \code{numeric vector} new input of the data
#' @param model \code{model} transfer function model
#' @param h \code{integer} prediction horizon
#' @return \code{numeric vector} new predictions
#' @export TF.forecast
TF.forecast <- function(y.old, x.old, x.new, model, h = 1) {
  #first extract regression error
  #regerr.old <- TF.RegressionError(y.old,x.old,model)
  coefval <- coef(model)
  coefnames <- attr(coefval, which = "names")
  xfilt.old <- MLTools::TF.filter(x.old, coefval, coefnames)

  #extract fitted info
  orders <- model$arma
  coefval <- coef(model)
  coefnames <- attr(coefval, which = "names")
  inter <- length(grep(c("intercept"), coefnames))

  #Creacion vfixed
  vfixed <- c()
  if (orders[1] > 0) {
    vfixed <- c(vfixed, coefval[seq(1, orders[1])])
  }
  if (orders[2] > 0) {
    vfixed <-
      c(vfixed, (1) * coefval[seq(orders[1] + 1 , orders[1] + orders[2])])
  }
  if (orders[3] > 0) {
    vfixed <-
      c(vfixed, coefval[seq(orders[1] + orders[2] + 1 , orders[1] + orders[2] +
                              orders[3])])
  }
  if (orders[4] > 0) {
    vfixed <-
      c(vfixed, (1) * coefval[seq(orders[1] + orders[2] + orders[3] + 1 ,
                                  orders[1] + orders[2] + orders[3] + orders[4])])
  }
  res <- y.old - xfilt.old
  #Obtain arima for regression error with ARIMA coefficients
  Arima.fit <- TSA::arima(
    res,
    order = c(orders[1], orders[6], orders[2]),
    seasonal = list(
      order = c(orders[3], orders[7], orders[4]),
      period = orders[5]
    ),
    fixed = vfixed,
    include.mean = FALSE
  )
  # Include output to the arima model
  Arima.fit$x <- res
  #forecast
  regerr.est <- forecast::forecast(Arima.fit, h = h)
  #Apply filter with new data
  xfilt <- MLTools::TF.filter(rbind(x.old, x.new), coefval, coefnames)
  #Obtain intercept
  indexcoef <- grep("intercept", coefnames)
  if (length(indexcoef) == 0) {
    inter <- 0
  } else {
    inter <- coefval[indexcoef]
  }
  #Add forecast
  y.est <- xfilt[(length(xfilt)-h+1):length(xfilt)] + inter + regerr.est$mean

  return(as.numeric(y.est))
}

#' Filter a numeric vector based on the coefficients of a model
#'
#' @description Filter a numeric vector based on the coefficients
#' of a transfer function model used to forecast.
#' @param x \code{numeric vector} vector to be filtered
#' @param coefval \code{numeric vector} coefficients of the transfer function model
#' @param coefnames \code{character vector} name of the coefficients of the transfer function model
#' @return \code{numeric vector} filtered numeric vector
#' @export TF.filter
TF.filter <- function(x, coefval, coefnames) {
  # Number of explanatory variables
  nx <- ncol(x)
  if (is.null(nx) &&
      is.null(attr(x, which = "names"))) {
    # One regressor variable
    # AR regression terms
    indexcoef <- grep("-AR", coefnames)
    if (length(indexcoef) > 0) {
      xfilt <-
        stats::filter(x,
               filter = coefval[indexcoef],
               method = 'recursive',
               sides = 1)
    } else {
      xfilt <- x # In case there are no -AR coefficients
    }
    # MA regression terms
    indexcoef <- grep("-MA", coefnames)
    if (length(indexcoef) > 0) {
      xfilt <-
        stats::filter(xfilt,
               filter = coefval[indexcoef],
               method = 'convolution',
               sides = 1)
    }
    xfiltTOT <- xfilt

  } else {
    # several regressor variables
    # variable names
    if (is.null(attr(x, which = "names"))) {
      nomx <- attr(x, which = "dimnames")[[2]]
    } else {
      nomx <- attr(x, which = "names")[[2]]
    }
    # init xfilt
    xfiltTOT <- x[, 1] * 0
    # loop
    for (i in 1:nx) {
      # AR regression terms
      indexcoef <- grep(paste(nomx[i], "-AR", sep = ""), coefnames)
      if (length(indexcoef) > 0) {
        xfilt <-
          stats::filter(x[, i],
                 filter = coefval[indexcoef],
                 method = 'recursive',
                 sides = 1)
      } else {
        xfilt <- x[, i] # In case there are no -AR coefficients
      }
      # MA regression terms
      indexcoef <- grep(paste(nomx[i], "-MA", sep = ""), coefnames)
      if (length(indexcoef) > 0) {
        xfilt <-
          stats::filter(xfilt,
                 filter = coefval[indexcoef],
                 method = 'convolution',
                 sides = 1)
      }
      xfiltTOT <- xfiltTOT + xfilt
    }
  }

  return(xfiltTOT)
}
