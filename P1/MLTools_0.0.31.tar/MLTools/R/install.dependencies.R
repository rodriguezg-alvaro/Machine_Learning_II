#' Install libraries needed for the rest of the functions
#' @export install.dependencies
install.dependencies <- function() {
  list.of.packages <- c("caret","ggplot2","direclabels",
                        "forecast","fpp2","gridExtra","mvtnorm",
                        "NeuralNetTools","NeuralSens","pROC",
                        "reshape2","ROCR","splines","dummies",
                        "kohonen","e1071","kernlab","gridExtra")
  # Install only missing packages
  new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
  if (length(new.packages)) install.packages(new.packages,dep = T)
}
