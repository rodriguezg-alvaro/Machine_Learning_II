#' Plot cluster classification
#'
#' @description Function for showing several plots with the cluster results
#' @param centers  vector of calculated centers of the clusters
#' @param clusters vector with the classification of the data
#' @param data data.frame with the data used to calculate the clusters
#' @section Output:
#' Several plots with the cluster results. It doesn't return anything
#' @examples
#' # Calculate clusters
#' km <- kmeans(fdata, k)
#' # Plot cluster results
#' plot.clusters(km$centers, km$cluster, fdata)
#' @export PlotClusters
PlotClusters <- function(centers, clusters, data) {
  # number of clusters
  nc <- length(unique(clusters))

  data <- as.data.frame(data)

  # check number of input variables.
  if (ncol(data) == 2) {
    colnames(data) <- c("v1", "v2")
    p <- ggplot2::ggplot(data) +
      ggplot2::geom_point(ggplot2::aes(x = v1, y = v2 , color = as.factor(clusters))) +
      ggplot2::labs(colour = "Cluster")
    if (!is.null(centers)) {
      datacent <- as.data.frame(centers[, 1:2])
      colnames(datacent) <- c("v1", "v2")
      p <- p + ggplot2::geom_point(data = datacent, ggplot2::aes(x = v1, y = v2), pch = 19, cex=2)
    }
    plot(p)
  } else {
    # Calculate principal components and plot clusters and data
    data.pca <- prcomp(data, center = TRUE, scale. = TRUE)
    dfplot <- data.frame(pc1 = data.pca$x[, 1], pc2 = data.pca$x[, 2], cluster = clusters)
    # #Plot
    # par(mfrow = c(floor(nc/2)+1, ceiling(nc/2)))
    # for (cc in sort(unique(clusters))) {
    #   matplot(t(as.matrix(data[clusters == cc, ])), type = "l", col = "yellow",
    #           ylab = "", xlab = colnames(data), main = paste("Cluster ", cc))
    #   if (!is.null(centers)) {
    #     lines(1:ncol(data), as.matrix(centers[cc, ]), type = "l", col = "black")
    #   }
    # }
    # par(mfrow = c(1, 1))

    p <- ggplot2::ggplot() + ggplot2::geom_point(data = dfplot, ggplot2::aes(x = pc1, y = pc2, color = as.factor(cluster))) +
      ggplot2::labs(colour = "Cluster")
    if (!is.null(centers)) {
      dfcent <- predict(data.pca, centers)
      p <- p +
        ggplot2::geom_point(data = as.data.frame(dfcent[, 1:2]), ggplot2::aes(x = PC1, y = PC2), color = "black", pch = 19, cex = 2)
    }
    print(p)

    if(!is.null(centers)) {
    P <- ggplot2::ggplot(reshape2::melt(as.matrix(centers))) +
      ggplot2::geom_line(ggplot2::aes(x = Var2, y = value, group = Var1, colour = as.factor(Var1))) +
      ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1)) +
      ggplot2::labs(colour = "Cluster")
    print(P)
    }
  }
}
