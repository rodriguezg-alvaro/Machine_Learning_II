#' Obtain the names of the most important variables for a model
#'
#' @description Function for obtaining the names of the most important variables for a model.
#' Useful to iterate and optimize the model. Only works for classification and regression models.
#' @param object \code{model} trained by the function \code{train} of \code{caret} package.
#' @param first \code{integer} number of most important variable required.
#' @param perc \code{numeric} percentage of importance that a variable must have to be important.
#' @section Warning:
#' \code{first} or \code{perc} are needed, but both can not have a value. If none has a value, the
#' scaled and non-scaled importance of the variables are returned.
#' @return \code{character vector} with the names of the variables
#' @export VarImp.ICAI
VarImp.ICAI <- function(object, first = NULL, perc = NULL, scale = FALSE,...) {
  impscl <- caret::varImp(object, scale = FALSE, ...)
  imp <- caret::varImp(object, scale = TRUE, ...)
  if (scale) {
    impboth <- cbind(imp$importance, impscl$importance)
  } else {
    impboth <- cbind(impscl$importance, imp$importance)
  }
  names(impboth) <- c("Scaled", "Not scaled")
  impboth <- impboth[order(impboth$Scaled, decreasing = TRUE),]
  if (!is.null(first) && !is.null(perc)) {
    print(impboth)
    stop("Arguments first and perc can not have a value")
  } else if (!is.null(first)) {
    print(impboth)
    return(row.names(impboth[1:first,]))
  } else if (!is.null(perc)) {
    print(impboth)
    return(row.names(impboth[which(impboth$Scaled > perc),]))
  } else {
    impboth <- list(importance = impboth,
                    model = object$modelInfo$library,
                    calledFrom = "VarImp.ICAI")
    attr(impboth, "class") = "varImp.train"
    return(impboth)
  }
}

#' Plot the importance of the variables with and without scaling
#'
#' @param varImp \code{varImp.train} created by the function \code{caret::varImp} or
#' \code{MLTools::VarImp.ICAI}
#' @param ... arguments to pass to the lattice plot function
#' (\code{\link[lattice:xyplot]{dotplot}} and \code{\link{panel.needle}})
#' @export plot.varImp
plot.varImp <- function(varImp, ...) {
  print(varImp$importance)
  if (ncol(varImp$importance)) {
    varImpInv <- varImp
    varImpInv$importance <- varImpInv$importance[, c(2, 1)]
    gp1 <- ggplot2::ggplot(varImp, mapping = NULL, top = dim(varImp$importance)[1], ..., environment = NULL)
    gp2 <- ggplot2::ggplot(varImpInv, mapping = NULL, top = dim(varImpInv$importance)[1], ..., environment = NULL)
    gplist <- list(gp1, gp2)
    gridExtra::grid.arrange(grobs = gplist, nrow = 2)
  } else {
    ggplot2::ggplot(varImp, mapping = NULL, top = dim(varImp$importance)[1], ..., environment = NULL)
  }
}
