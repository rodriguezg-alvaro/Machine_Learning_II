R package for ML courses
